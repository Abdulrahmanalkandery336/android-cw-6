public class movie {
    private String title ;
    private String mainactor ;
    private Double movierate ;
    private int  pgrate ;
    private String genre ;
}
